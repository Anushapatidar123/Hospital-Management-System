# Hospital Management System Console Application - C++

Hospital Management System Project in C++ using classes was create using a simple console application. 

This program is open to all hospital users without the need for login information in this program. 

The system user can select the category in which they specialize by simply entering a series of numeric keys.

NOTE: RUN THE PROGRAM IN FULL SCREEN ONLY

Screenshot from application below: 

![mail 2](https://user-images.githubusercontent.com/63939366/163225032-1ff25481-bf43-4a09-b81c-4eacbc207cf8.png)
